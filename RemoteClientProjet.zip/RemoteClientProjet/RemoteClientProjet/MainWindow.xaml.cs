﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RemoteClientProjet
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Socket client = null;
        Thread ThreadClient;
        Thread Ecoute;

        public MainWindow()
        {
            InitializeComponent();
            this.ConnectInfo.Content = "Waiting for server's connection ... ";
            //this.ThreadClient = new Thread(new ThreadStart(this.initialisation));
            //ThreadClient.Start();

        }

        public void LabelUpdateInfo(string txt)
        {
            this.ConnectInfo.Content = txt;

        }

        public void LabelUpdateState(string txt)
        {
            this.SaveName.Content = txt;

        }

        public void initialisation()
        {
            this.client = this.Seconnecter();

            this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal,(ThreadStart)delegate { this.LabelUpdateInfo("Connect to " + this.client.AddressFamily.ToString()); });
            //this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, (ThreadStart)delegate { this.LabelUpdateState("HDHDHDHD"); });
            this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, (ThreadStart)delegate { this.LabelUpdateState("ecoute en cours"); });
            //Ecouter(this.client);
            this.Ecoute = new Thread(new ThreadStart(delegate { this.Ecouter(this.client); }));
            Ecoute.Start();



        }

        public Socket Seconnecter()
        {
            string host = Dns.GetHostName();
            int port = 11000;
            IPHostEntry ipHostName = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = IPAddress.Any;
            IPEndPoint ipRemoteEP = new IPEndPoint(ipAddress, port);

            // Create a TCP/IP  socket.
            Socket client = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            while (true)
            {
                try
                {
                    client.Connect(host, port);
                    break;
                }
                catch (Exception ex)
                {
                }
            }
            return client;
        }

        private static void Deconnecter(Socket socket)
        {
            socket.Close();
        }

        public void Ecouter(Socket client)
        {
            try
            {
                //this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, (ThreadStart)delegate { this.LabelUpdateState("eHAHAHAHAHAHAcoute en cours"); });

                while (true)
                {
                    byte[] messageReceived = new byte[1024];
                    int ByteRecv = client.Receive(messageReceived);
                    
                    string receivedstring = Encoding.ASCII.GetString(messageReceived, 0, ByteRecv);
                    ByteRecv = client.Receive(messageReceived);
                    receivedstring = Encoding.ASCII.GetString(messageReceived, 0, ByteRecv);
        
                    this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, (ThreadStart)delegate { this.LabelUpdateState("Test" + receivedstring.ToString()); });






                }


            }
            catch (Exception ex)
            {

            }
        }
        private void Update(string data)
        {

        }


        private void DisconnectButton(object sender, RoutedEventArgs e)
        {
            Deconnecter(this.client);
            this.Dispatcher.BeginInvoke(
                System.Windows.Threading.DispatcherPriority.Normal,
                (ThreadStart)delegate { this.LabelUpdateInfo("Disconnected of " + this.client.AddressFamily.ToString()); });
            this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, (ThreadStart)delegate { this.LabelUpdateState(""); });
        }
        private void ReconnectButton(object sender, RoutedEventArgs e)
        {
            this.ThreadClient = new Thread(new ThreadStart(this.initialisation));
            ThreadClient.Start();
            //  this.client = this.Seconnecter();
            //   this.Ecoute2 = new Thread(new ThreadStart(delegate { this.Ecouter(this.client); }));
            //   Ecoute2.Start();
            //this.Dispatcher.BeginInvoke(
            //    System.Windows.Threading.DispatcherPriority.Normal,
            //    (ThreadStart)delegate { this.LabelUpdateInfo("Connect to " + this.client.AddressFamily.ToString()); });
        }

        private void PlayClick(object sender, RoutedEventArgs e)
        {
            if (this.client != null)
            {
                string msg = "action : play";
                byte[] bmsg = Encoding.UTF8.GetBytes(msg);
                try
                {
                    this.client.Send(bmsg);
                }
                catch (Exception ex)
                {

                }
            }
        }
        private void PauseClick(object sender, RoutedEventArgs e)
        {
            if (this.client != null)
            {
                string msg = "action : pause";
                byte[] bmsg = Encoding.UTF8.GetBytes(msg);
                try
                {
                    this.client.Send(bmsg);
                }
                catch (Exception ex)
                {

                }
            }
        }
        private void StopClick(object sender, RoutedEventArgs e)
        {
            if (this.client != null)
            {
                string msg = "action : stop";
                byte[] bmsg = Encoding.UTF8.GetBytes(msg);
                try
                {
                    this.client.Send(bmsg);
                }
                catch (Exception ex)
                {

                }
            }
        }
    }
}
